package dev.mobileperf.sodium;

import dev.mobileperf.PerfConfig;
import net.caffeinemc.mods.sodium.api.config.ConfigEntryPoint;
import net.caffeinemc.mods.sodium.api.config.structure.ConfigBuilder;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;

public class MobilePerfSodiumConfig implements ConfigEntryPoint {
    @Override
    public void registerConfigLate(ConfigBuilder builder) {
        builder.registerOwnModOptions()
                .addPage(builder.createOptionPage()
                        .setName(Component.translatable("mobileperf.page"))
                        .addOptionGroup(builder.createOptionGroup()
                                .setName(Component.translatable("mobileperf.group.particles"))
                                .addOption(builder.createBooleanOption(Identifier.parse("mobileperf:particle_cull"))
                                        .setName(Component.translatable("mobileperf.opt.particle_cull.name"))
                                        .setTooltip(Component.translatable("mobileperf.opt.particle_cull.tooltip"))
                                        .setStorageHandler(() -> PerfConfig.save())
                                        .setBinding(v -> PerfConfig.get().particleCull = v, () -> PerfConfig.get().particleCull)
                                        .setDefaultValue(true))
                                .addOption(builder.createIntegerOption(Identifier.parse("mobileperf:particle_dist"))
                                        .setName(Component.translatable("mobileperf.opt.particle_dist.name"))
                                        .setTooltip(Component.translatable("mobileperf.opt.particle_dist.tooltip"))
                                        .setStorageHandler(() -> PerfConfig.save())
                                        .setRange(8, 128, 4)
                                        .setValueFormatter(v -> Component.translatable("mobileperf.blocks", v))
                                        .setBinding(v -> PerfConfig.get().particleMaxDistance = v, () -> PerfConfig.get().particleMaxDistance)
                                        .setDefaultValue(48)))
                        .addOptionGroup(builder.createOptionGroup()
                                .setName(Component.translatable("mobileperf.group.entities"))
                                .addOption(builder.createBooleanOption(Identifier.parse("mobileperf:entity_cull"))
                                        .setName(Component.translatable("mobileperf.opt.entity_cull.name"))
                                        .setTooltip(Component.translatable("mobileperf.opt.entity_cull.tooltip"))
                                        .setStorageHandler(() -> PerfConfig.save())
                                        .setBinding(v -> PerfConfig.get().entityCull = v, () -> PerfConfig.get().entityCull)
                                        .setDefaultValue(true))
                                .addOption(builder.createIntegerOption(Identifier.parse("mobileperf:entity_dist"))
                                        .setName(Component.translatable("mobileperf.opt.entity_dist.name"))
                                        .setTooltip(Component.translatable("mobileperf.opt.entity_dist.tooltip"))
                                        .setStorageHandler(() -> PerfConfig.save())
                                        .setRange(16, 256, 8)
                                        .setValueFormatter(v -> Component.translatable("mobileperf.blocks", v))
                                        .setBinding(v -> PerfConfig.get().entityMaxDistance = v, () -> PerfConfig.get().entityMaxDistance)
                                        .setDefaultValue(64))));
    }
}
