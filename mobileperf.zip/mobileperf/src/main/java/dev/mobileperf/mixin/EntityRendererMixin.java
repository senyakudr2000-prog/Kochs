package dev.mobileperf.mixin;

import dev.mobileperf.PerfConfig;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.renderer.culling.Frustum;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.boss.enderdragon.EnderDragon;
import net.minecraft.world.entity.boss.wither.WitherBoss;
import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(EntityRenderer.class)
public class EntityRendererMixin {
    @Inject(method = "shouldRender", at = @At("HEAD"), cancellable = true)
    private void mobileperf$cullFar(Entity entity, Frustum frustum, double camX, double camY, double camZ,
                                    CallbackInfoReturnable<Boolean> cir) {
        PerfConfig cfg = PerfConfig.get();
        if (!cfg.entityCull) {
            return;
        }
        if (entity instanceof Player || entity instanceof EnderDragon || entity instanceof WitherBoss) {
            return;
        }
        LocalPlayer player = Minecraft.getInstance().player;
        if (player == null) {
            return;
        }
        double max = cfg.entityMaxDistance;
        if (player.distanceToSqr(entity) > max * max) {
            cir.setReturnValue(false);
        }
    }
}
