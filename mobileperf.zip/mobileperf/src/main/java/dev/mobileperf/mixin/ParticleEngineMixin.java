package dev.mobileperf.mixin;

import dev.mobileperf.PerfConfig;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.particle.ParticleEngine;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.particles.ParticleOptions;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(ParticleEngine.class)
public class ParticleEngineMixin {
    @Inject(method = "createParticle", at = @At("HEAD"), cancellable = true)
    private void mobileperf$cullFar(ParticleOptions options, double x, double y, double z,
                                    double vx, double vy, double vz,
                                    CallbackInfoReturnable<Particle> cir) {
        PerfConfig cfg = PerfConfig.get();
        if (!cfg.particleCull) {
            return;
        }
        LocalPlayer player = Minecraft.getInstance().player;
        if (player == null) {
            return;
        }
        double max = cfg.particleMaxDistance;
        if (player.distanceToSqr(x, y, z) > max * max) {
            cir.setReturnValue(null);
        }
    }
}
